Scientific Paper Recommendation System - PROCS/Procedia LaTeX Project

This project is adapted from the supplied PROCS_ICMLDE Procedia Computer Science LaTeX template.

Main file:
- main.tex

Stage 1 sections included:
1. Problem Definition
2. Related Work
3. Proposed Approach
4. Methodology and Implementation

IMPORTANT:
- Replace the author names and affiliation placeholders in main.tex.
- Verify the model, dataset, vector database/index, and implementation details against your actual project before submission.
- Do not claim experimental results until you have run the experiments.
- The supplied friend template is an Elsevier Procedia Computer Science template, not the official IEEEtran conference template. If your faculty specifically requires IEEEtran, use an IEEEtran template instead.
